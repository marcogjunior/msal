
# Angular Scaffold (copy into your Angular CLI workspace)
- `ng new minimalamp-spa --routing --style=scss`
- `cd minimalamp-spa && npm i @azure/msal-browser @azure/msal-angular`
- Copy `src/app/**` and `src/environments/**` from this scaffold into your app
- Edit `environment.ts` with Terraform outputs
- `ng serve -o`
